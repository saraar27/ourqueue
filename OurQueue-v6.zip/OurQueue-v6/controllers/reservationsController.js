const reservation = require('../models/reservation');

const { validationResult } = require('express-validator');
const isLogin = require("../middleware/isLogin");
const User = require("../models/user");
// Open web pages routes



const open_search_reservation_page = (request, response) => {
  response.render('search_reservations', {title: 'Search reservation', reservations: null});
}



// read functions

const find_reservations = (req, res) => {
  const name = req.body.name;

  reservation.find({ name: name })
    .then((reservations) => {
      res.render('viewUserReservation', { title: 'View User Reservations', reservations: reservations });
    })
    .catch((error) => {
      console.error(`Error searching reservations by email: ${error.message}`);
      res.status(500).send('Internal Server Error');
    });
};
////////////////////////////////
const view_reservations = (request, response) => {
 
  reservation.find()
    .then((data) => {
      if(response._closed == false)
        response.render('viewAllReservation', {title: "view all reservations", reservations: data});
    })
    .catch((err) => { console.log(err) })
};
//////////////////////////////////////////////////



const add_reservation = (request, response) => {

 
  let name   = request.body.name; 
  let email= request.body.email;
  let phone= request.body.phone;
  let people= request.body.people;
  let date= request.body.date;
  let time= request.body.time;
  let message= request.body.message;

  const errors = validationResult(request);
  if (!errors.isEmpty()) {
     return response.status(422).json({ errors: errors.array() });
  }

  let art = new reservation({ name:name,email: email, phone: phone,people:people,date:date ,time:time , message:message});
  art.save()
    .then((data) => {
      console.log(`reservation saved to database: id -> ${data._id}`);
      
      response.send(`
        <script>
          alert('Reservation sent successfully! We will contact you to confirm your reservation.');
          window.location.href = '/dashboarduser';
        </script>
      `);
    })
    .catch((err) => { console.log(err) });
};
/////////////////////////
const delete_reservation = (request, response) => {
  let id = request.body.id;

  reservation.findByIdAndDelete(id)
    .then((result) => {
      console.log(`reservation deleted from database: id -> ${result.id}`);
      response.send(`
        <script>
          alert('Reservation Deleted!');
          window.location.href = '/dashboardadmin';
        </script>
      `);
    })
    .catch((err) => { console.log(err) });
};
///////////////////////////////////

module.exports = { open_search_reservation_page,
                  find_reservations, 
                  add_reservation,  delete_reservation,view_reservations
                };
////////////////////////////////
              