const express = require('express');
const userController = require('../controllers/userController');


const { check } = require('express-validator');
const isLogin = require("../middleware/isLogin");
const isLoginadmin = require('../middleware/isLoginadmin');
const userrouter = express.Router();


//userrouter.get("/", userController.landing_page);

userrouter.get("/login", userController.login_get);
userrouter.post("/login", userController.login_post);

// Register Page
userrouter.get("/register", userController.register_get);
userrouter.post("/register", userController.register_post);

// Dashboard Page
userrouter.get("/dashboarduser", isLogin, userController.dashboard_get);

userrouter.post("/logout", userController.logout_post);
////////////////////////
userrouter.get('/profile',  isLogin, userController.profile_get);


userrouter.get('/newReservation' , isLogin,  userController.open_add_reservation_page);
userrouter.get('/viewallusers' , isLoginadmin,  userController.view_users);
//////////////////////////////

module.exports = userrouter;