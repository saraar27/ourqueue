const express = require('express');
const adminController = require('../controllers/adminController');

const { check } = require('express-validator');
const isLoginadmin = require("../middleware/isLoginadmin");
const admiinrouter = express.Router();


admiinrouter.get("/loginadmin", adminController.loginadmin_get);
admiinrouter.post("/loginadmin", adminController.loginadmin_post);

// Register Page
admiinrouter.get("/registeradmin", adminController.registeradmin_get);
admiinrouter.post("/registeradmin", adminController.registeradmin_post);

// Dashboard Page
admiinrouter.get("/dashboardadmin", isLoginadmin, adminController.dashboardadmin_get);

admiinrouter.use("/logoutadmin", adminController.logoutadmin_post);

module.exports = admiinrouter;